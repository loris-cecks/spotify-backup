from hscommon.testutil import app  # noqa
