Démarrage rapide
=================

Voici les étapes à suivre pour faire un simple scan par défaut:

* Démarrer dupeGuru.
* Ajouter les dossiers à scanner soit avec le drag & drop, soit avec le boutton "+".
* Cliquez sur **Scan**.
* Attendez que le scan soit completé.
* Vérifiez que les doublons (les fichiers légèrement indentés) soient  vraiment le doublon de la référence du groupe (le fichier au haut du groupe qui ne peut pas être marqué).
* Si vous voyer un faux doublon, sélectionnez le puis cliquez sur l'action **Retirer sélectionnés des résultats**.
* Quand vous êtes certains de ne pas avoir de faux doublons dans vos résultats, cliquez sur **Tout marquer** dans le menu Marquer et cliquez sur l'action **Envoyer marqués à la corbeille**.

Ceci est seulement un scan de base. Il est possible de configurer dupeGuru afin d'obtenir exactement le type de résultat recherché. Pour en savoir plus, il lisez le reste du fichier d'aide.
