hscommon.gui.text_field
=======================

.. automodule:: hscommon.gui.text_field

    .. autosummary::
        
        TextField
        TextFieldView
    
    .. autoclass:: TextField
        :members:
        :private-members:

    .. autoclass:: TextFieldView
        :members:
