hscommon.gui.tree
=================

.. automodule:: hscommon.gui.tree
    
    .. autosummary::
        
        Tree
        Node
    
    .. autoclass:: Tree
        :members:
        :private-members:
    
    .. autoclass:: Node
        :members:
        :private-members:

