hscommon.gui.column
============================

.. automodule:: hscommon.gui.column

    .. autosummary::
        
        Columns
        Column
        ColumnsView
        PrefAccessInterface
    
    .. autoclass:: Columns
        :members:
        :private-members:
    
    .. autoclass:: Column
        :members:
        :private-members:
    
    .. autoclass:: ColumnsView
        :members:
    
    .. autoclass:: PrefAccessInterface
        :members:
