hscommon.gui.progress_window
============================

.. automodule:: hscommon.gui.progress_window

    .. autosummary::
        
        ProgressWindow
        ProgressWindowView
    
    .. autoclass:: ProgressWindow
        :members:
        :private-members:
    
    .. autoclass:: ProgressWindowView
        :members:
        :private-members:
    
