hscommon.gui.table
==================

.. automodule:: hscommon.gui.table
    
    .. autosummary::
        
        Table
        Row
        GUITable
        GUITableView
    
    .. autoclass:: Table
        :members:
        :private-members:
    
    .. autoclass:: Row
        :members:
        :private-members:

    .. autoclass:: GUITable
        :members:
        :private-members:
    
    .. autoclass:: GUITableView
        :members:
