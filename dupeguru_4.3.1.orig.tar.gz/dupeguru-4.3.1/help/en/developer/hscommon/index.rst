hscommon
========

.. toctree::
    :maxdepth: 2
    :glob:
    
    build
    conflict
    desktop
    notify
    path
    util
    jobprogress/*
    gui/*

