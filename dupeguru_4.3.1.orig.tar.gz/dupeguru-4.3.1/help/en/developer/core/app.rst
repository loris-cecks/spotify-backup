core.app
========

.. automodule:: core.app
    :members:
