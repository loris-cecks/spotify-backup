core.gui
========

.. automodule:: core.gui
    :members:

.. toctree::
    :maxdepth: 2
    
    deletion_options
