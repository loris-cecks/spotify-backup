core.gui.deletion_options
=========================

.. automodule:: core.gui.deletion_options
    :members:
