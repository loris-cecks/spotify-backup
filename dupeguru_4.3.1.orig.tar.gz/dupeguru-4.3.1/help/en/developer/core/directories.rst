core.directories
================

.. automodule:: core.directories
    :members:
